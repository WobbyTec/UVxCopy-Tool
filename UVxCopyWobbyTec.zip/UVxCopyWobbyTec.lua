-- Author: Wobby
-- Name: UVx-Copy-WobbyTec
-- Description: shows all UV-Sets of selected Mesh/Shape
-- Icon:iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABHNCSVQICAgIfAhkiAAAA0RJREFUOI11k0toXGUcxc/33Xu/mblzM5l3ZjITY5M0ZmRKbX1AWkqkrgq13bVSoWgNqAuRFlzoQigipEVBbEGpoAjFrRVqsaBufBWk4CNN2tqYdCaTTjKZO++57/t35aLWnNVZHH6cxTkMW+jC7CEU90Tj6cHOCa9Z1rpm+FzXDtdnTl65LydvBSgWyzybNl8anoy/49e7rFZ176oGPvtvjm8FkAOeRPbqtMIaQiTHlKDG9lVWh+JX3z2ivnxgDj++d/jBBn9fOg41RFKnuSj0FkkrJSynkzd8YoybtcChidTCFPlovHawctG2/S8BmAwAzpx6AUf3taVI4NedUiB6sKxHC7ZleGHumz3dPpwfUxOqpoO7DZAnwWiHeg1dm2u2E+/LALB3uxX8+ffV2eknsm/kR3flxh+ZkFptg1Sn5BubGxTLOmDWGnNchRjXoKlmmNA71bNj16RvvrggjYjfjmfStbO5QiElEkXW4QV4PIUgNjnvzzNGS7BYElJkGrIIQ/LvAq4btHoR4mHz9qhC1ZPx3K6Bhf7zrGmmWUUfYQulLGxXJqu7yVwaZOFEgQUiDzGIHIMYZlwiJomBSe54dIA5jcmWdox9/0uf6psGNRsdWlu6DmbVABGjUCRPcCrUr/9BRmuefHODXFsiVx6pyK5tTvvcl7i+iMfGMxiSLmMgXkPh8RWQMc/I7VCv0gBEH8FEATKrwu7Y6LYS652+c042PU4eaRClj7E7a0EYLoRXYn9VJyiFWwg4KvSyjGAqyhSlT4buotXI1O+1p+Y2WOqa3GPaT4YTeI73bb52y0d/6k2o8Qm6sfQVnslrcCwVAeGhdU80F0uxZcYyS103/fn16JNX20Mzjtzq4et1lnh1TOnuEG4A335wHtqKgqdf2QZF3QYW18BbTUfRB84ulx79yBExe11kjdMnZgkA5EZ0qnKn1j4TQvfDjFqP79lpIDBqIJqtQEnvJik27vXL5SuGo3wytn1Hc//RF++bvPTd5Uv01P5nF9vu4Aq5/sODEZ7UcgqnkEqWyG403PzFsp54y7aU6syR1x/4DPvXvH3+Ux5t3hlKRqS9gjlFWWG60NQfOkbo5p+rw8bc6WP/e7p/AHHDgdLXvbjkAAAAAElFTkSuQmCC
-- Namespace: local
-- AlwaysLoaded: no
-- Hide: no

CreateUVviewing = {}
CreateUVviewing.WINDOW_WIDTH = 420
CreateUVviewing.WINDOW_HEIGHT = 650
CreateUVviewing.NUMBER_DUPLICATE_NAMES = 0
CreateUVviewing.NUMBER_WHITESPACE_NAMES = 0
function CreateUVviewing.new()
    local self = setmetatable({}, {__index = CreateUVviewing})
    self.window = nil
    self.defaultMappingsText = "\n"
    self.mappingsTextAreaText = self.defaultMappingsText

    if g_createUVviewing ~= nil then
        g_createUVviewing:close()
    end
    self:generateUI()
    g_createUVviewing = self
    self:createMappings(true)
    return self
end
function CreateUVviewing:generateUI()
    local frameRowSizer = UIRowLayoutSizer.new()
    self.window = UIWindow.new(frameRowSizer, "UVx-Copy-WobbyTec (UV1-UVx v1.0")

    local borderSizer = UIRowLayoutSizer.new()
    UIPanel.new(frameRowSizer, borderSizer, -1, -1, -1, -1, BorderDirection.NONE, 0, 1)

    local rowSizer = UIRowLayoutSizer.new()
    UIPanel.new(borderSizer, rowSizer, -1, -1,
        CreateUVviewing.WINDOW_WIDTH,
        CreateUVviewing.WINDOW_HEIGHT - 180,
        BorderDirection.ALL, 10, 1)

    self.mappingsTextArea = UITextArea.new(
        rowSizer,
        self.mappingsTextAreaText,
        TextAlignment.LEFT,
        false,
        true,
        -1, -1,
        CreateUVviewing.WINDOW_WIDTH - 40,
        CreateUVviewing.WINDOW_HEIGHT - 220,
        BorderDirection.ALL,
        1, 1
    )
    local colSizer = UIColumnLayoutSizer.new()
    UIPanel.new(borderSizer, colSizer, -1, -1, -1, 140, BorderDirection.BOTTOM, 10)
    local buttonRow1 = UIRowLayoutSizer.new()
    UIPanel.new(colSizer, buttonRow1, -1, -1, -1, 40, BorderDirection.NONE, 5, 1)

    UIButton.new(buttonRow1, "🔄 Show ALL UV From Selected",
        function() self:createMappings(true) end,
        nil,
        180, -1, -1, 35,
        BorderDirection.LEFT, 5, 1)
    UIButton.new(buttonRow1, "📋 Copy All",
        function() self:copyAll() end,
        nil,
        90, -1, -1, 35,
        BorderDirection.NONE, 5, 1)
    UIButton.new(buttonRow1, "copy UV2 (GE v10.x !!)",
        function() self:copyUVSet(2) end,
        nil,
        90, -1, -1, 35,
        BorderDirection.NONE, 5, 1)
    UIButton.new(buttonRow1, "copy UV3 (GE v10.x !!)",
        function() self:copyUVSet(3) end,
        nil,
        90, -1, -1, 35,
        BorderDirection.NONE, 5, 1)
    UIButton.new(buttonRow1, "✏️ Clear",
        function() self.mappingsTextArea:setValue("") end,
        nil,
        90, -1, -1, 35,
        BorderDirection.NONE, 5, 1)
    local buttonRow2 = UIRowLayoutSizer.new()
    UIPanel.new(colSizer, buttonRow2, -1, -1, -1, 40, BorderDirection.NONE, 5, 1)
    UIButton.new(buttonRow2, "Clear",
        function() self.mappingsTextArea:setValue("") end,
        nil,
        180, -1, -1, 35,
        BorderDirection.RIGHT, 5, 1)
    UIButton.new(buttonRow2, "🗂️ Save to File",
        function() self:saveToFile() end,
        nil,
        90, -1, -1, 35,
        BorderDirection.RIGHT, 5, 1)
    UIButton.new(buttonRow2, "❌ Close",
        function() self:close() end,
        nil,
        90, -1, -1, 35,
        BorderDirection.RIGHT, 5, 1)
    local function showMessageBox()
        local aboutText =
            "UVx-Copy WobbyTec(ALL UV Sets) v1.0\n\n" ..
            "Features:\n" ..
            "• all UV-Sets will detected automatically (UV1, UV2, UV3, UV4, ...)\n" ..
            "• Scrolling TextArea (Copy/Paste möglich)\n" ..
            "• Copy only UV2 / Copy only UV3 / Copy All UVs \n\n" ..
            "YTChannel: https://www.youtube.com/@Wobby_\n\n" ..
            "Copyright © WobbyTec"
        self:showMessageBox(aboutText, "About")
    end
    UIButton.new(buttonRow2, "ℹ️",
        showMessageBox,
        nil,
        -1, -1, 35, 35,
        BorderDirection.RIGHT, 5, -1)

    self.window:setOnCloseCallback(function() self:onClose() end)
    self.window:showWindow()
end
local function getNodeChain(node)
    local chain = {}
    local cur = node

    while cur and cur ~= 0 do
        table.insert(chain, 1, string.format("%s (%d)", tostring(getName(cur)), getChildIndex(cur)))
        cur = getParent(cur)
    end
    return table.concat(chain, " | ")
end
local function buildUVTextForNode(node)
    local text = ""
    local anyUV = false
    local foundSets = {}
    text = text .. "Node-Hierarchie:\n" .. getNodeChain(node) .. "\n"
    text = text .. string.rep("=", 60) .. "\n"
    for uvIndex = 1, 8 do
        local vertexCount, vertexTexCoords = getShapeVertexTexCoords(node, uvIndex - 1)
        if vertexCount and vertexCount > 0 and vertexTexCoords then
            anyUV = true
            table.insert(foundSets, string.format("UV%d", uvIndex))  

            text = text .. string.format("\n🌟 UV Set %d: %d Vertices", uvIndex, vertexCount)
            text = text .. string.rep("-", 40) .. "\n"

            local maxLines = 100000
            for i = 1, math.min(vertexCount, maxLines) do
                local u = vertexTexCoords[i * 2 - 1] or 0
                local v = vertexTexCoords[i * 2] or 0
                text = text .. string.format("vt %.6f %.6f\n", u, v)
            end
            if vertexCount > maxLines then
                text = text .. string.format("\n... (%d weitere Vertices gekürzt)\n", vertexCount - maxLines)
            end
        end
    end
if anyUV then
        local list = table.concat(foundSets, ", ")
        text = text:gsub(
            string.rep("=", 60) .. "\n",
            string.rep("=", 60) .. "\n*** GEFUNDENE UV-SETS: " .. list .. " ***\n\n",
            1
        )
    else
        text = text .. "\n❌ KEINE UV-Sets für dieses Shape gefunden.\n"
    end
    text = text .. "\n" .. string.rep("=", 60) .. "\n"
    return text
end
function CreateUVviewing:createMappings(selectedOnly)
    if not selectedOnly then
        self.mappingsTextArea:setValue("Info:\n - Nur 'Show ALL UV From Selected' will supported.")
        return
    end
    local numSelected = getNumSelected()
    if numSelected <= 0 then
        self.mappingsTextArea:setValue("Info:\n - please select a shape/mesh before run..")
        return
    end
    local text = ""
    for i = 1, numSelected do
        local node = getSelection(i - 1)
        if node and node ~= 0 then
            text = text .. string.format("\n=== Selektion %d ===\n", i)
            text = text .. buildUVTextForNode(node)
        end
    end
    self.mappingsTextArea:setValue(text)
end
function CreateUVviewing:copyAll()
    if self.mappingsTextArea ~= nil then
        local text = self.mappingsTextArea:getValue():match("^(.*%S)%s*$")
        setClipboard(text)
        self:showMessageBox("The text has been copied to the clipboard!\n you can paste directly into an editor using Ctrl + V", "✅ Copy OK")
    end
end
function CreateUVviewing:copyUVSet(uvIndex)
    if self.mappingsTextArea == nil then
        return
    end
    local text = self.mappingsTextArea:getValue() or ""
    if text == "" then
        self:showMessageBox("no data available ..", "Info")
        return
    end
    local header = string.format("🌟 UV Set %d:", uvIndex)
    local startPos = string.find(text, header, 1, true)  -- plain search [web:68]
    if not startPos then
        self:showMessageBox(string.format("no Block for %s found.", header), "Info")
        return
    end
    local subText = string.sub(text, startPos)
    local block
    if uvIndex == 2 then
        local nextHeader = "🌟 UV Set 3:"
        local relNextStart = string.find(subText, nextHeader, 1, true)
        if relNextStart then
            block = string.sub(subText, 1, relNextStart - 1)
        else
            block = subText
        end
    else
        local relNextStart = string.find(subText, "🌟 UV Set ", #header + 1, true)
        if relNextStart then
            block = string.sub(subText, 1, relNextStart - 1)
        else
            block = subText
        end
    end
    local lines = {}
    for line in string.gmatch(block, "([^\r\n]+)") do
        if string.sub(line, 1, 3) == "vt " then
            table.insert(lines, line)
        end
    end
    local count = #lines
    local vtOnly = table.concat(lines, "\n")
    vtOnly = vtOnly:match("^%s*(.-)%s*$") or vtOnly  -- trim

    if vtOnly == "" then
        self:showMessageBox(string.format("no vt‑Cells for %s were found.", header), "Info")
        return
    end
    setClipboard(vtOnly)
    self:showMessageBox(string.format(
        "vt lines for %s copied to clipboard!\n\nnumber Lines: %d",
        header, count
    ), "✅ Copy OK")
end
function CreateUVviewing:saveToFile()
    local text = self.mappingsTextArea:getValue()
    print("\n=== UV-DATEN ZUM KOPIEREN (Save simulieren) ===")
    print(text)
    print("=== ENDE ===")
    self:showMessageBox("please use CopyAll function..\nand paste directly into an editor using Ctrl + V", "💾 Save")
end
function CreateUVviewing:showMessageBox(text, title)
    if text ~= nil then
        if MessageBox == nil then
            source("ui/MessageBox.lua")
        end
        if self.messageBoxWindow ~= nil then
            self.messageBoxWindow:close()
        end
        self.messageBoxWindow = MessageBox.show(title or "Message", text, function() self.messageBoxWindow = nil end)
    end
end
function CreateUVviewing:close()
    if self.window ~= nil then
        self.window:close()
    end
end
function CreateUVviewing:onClose()
    if self.messageBoxWindow ~= nil then
        self.messageBoxWindow:close()
    end
    g_createUVviewing = nil
end

CreateUVviewing.new()
